document.addEventListener('DOMContentLoaded', function () {
    var carto = L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '',
        subdomains: 'abcd',
        maxZoom: 20
    });

    var customIcon = L.icon({
        iconUrl: './google-maps.png',
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32]
    });

    var map = L.map('map', {
        center: [18.802830795122798, 98.95038193273236],
        zoom: 13,
        zoomControl: true,
        doubleClickZoom: false,
        scrollWheelZoom: false,
        boxZoom: false,
        keyboard: false,
        dragging: false,
        touchZoom: 'true',
        layers: [carto]
    });

    var marker_eng = L.marker([18.795739594690353, 98.9530624508629], { icon: customIcon }).addTo(map).on('click', onMarkerClick);
    var marker_rmutl = L.marker([18.809792610881917, 98.95671263406584], { icon: customIcon }).addTo(map).on('click', onMarkerClick);
    var marker_uni = L.marker([18.79417009002368, 98.9667513685618], { icon: customIcon }).addTo(map).on('click', onMarkerClick);
    var marker_maehia = L.marker([18.76139615376945, 98.93185143728131], { icon: customIcon }).addTo(map).on('click', onMarkerClick);

    var cities = L.layerGroup([marker_eng, marker_rmutl, marker_uni, marker_maehia]).addTo(map);

    var baseMaps = {
        "test1": carto
    };

    var overlayMaps = {
        "Markers": cities
    };

    L.control.layers(baseMaps, overlayMaps).addTo(map);

    function onMarkerClick(e) {
        var card = document.getElementById('info-card');
        var cardContent = document.getElementById('card-content');

        if (e.target === marker_eng) {
            cardContent.innerHTML = `
                <img src="./image/Cam007_20240223090003.jpg" alt="Image 1" class="card-image"/>
                <h2>คณะวิศวกรรมศาสตร์ มหาวิทยาลัยเชียงใหม่</h2>
                <p>ST: คณะวิศวกรรมศาสตร์ มหาวิทยาลัยเชียงใหม่</p>
            `;
        } else if (e.target === marker_rmutl) {
            cardContent.innerHTML = `
                <img src="./Cam005_20240204120002.jpg" alt="Image 2" class="card-image"/>
                <h2>มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา</h2>
                <p>ST: มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา</p>
            `;
        } else if (e.target === marker_uni) {
            cardContent.innerHTML = `
                <img src="./image/Cam008_20240323150003.jpg" alt="Image 4" class="card-image"/>
                <h2>สํานักบริการวิชาการ มหาวิทยาลัยเชียงใหม่</h2>
                <p>ST: สํานักบริการวิชาการ มหาวิทยาลัยเชียงใหม่</p>
            `;
        } else if (e.target === marker_maehia) {
            cardContent.innerHTML = `
            <img src="./image/Cam001_20240220160002.jpg" alt="Image 3" class="card-image"/>
            <h2>มหาวิทยาลัยเชียงใหม่ (แม่เหียะ)</h2>
            <p>ST: มหาวิทยาลัยเชียงใหม่ (แม่เหียะ)</p>
            `;
        }

        card.classList.remove('hidden');
        document.body.classList.add('blur-background');
    }

    document.getElementById('close-card').addEventListener('click', function () {
        document.getElementById('info-card').classList.add('hidden');
        document.body.classList.remove('blur-background');
    });

    function showLoadingScreen() {
        document.getElementById('loading-screen').style.display = 'flex';

        setTimeout(function () {
            document.getElementById('loading-screen').style.display = 'none';
        }, 1000);
    }

    window.addEventListener('load', function () {
        showLoadingScreen();
    });
});









let lastupdateObject = [];

const get_data_lastupdateAPI = async () => {
    const stations = [6, 106, 2004, 4439];
    try {
        const requests = stations.map(station => {
            const url = `http://localhost:3000/api/database/lastupdate/${station}`;
            return axios.get(url).then(res => res.data);
        });

        const results = await Promise.all(requests);
        lastupdateObject = results;
        Filter_station(lastupdateObject);

    } catch (error) {
        console.error("Error fetching data:", error);
    }
}

const Filter_station = (lastupdateObjects) => {
    console.log(lastupdateObjects);

    lastupdateObjects.forEach(obj => {
        const { station } = obj;

        if (station == 6) {
            console.log(obj);

        } else if (station == 106) {
            console.log(obj);

        } else if (station == 2004) {
            console.log(obj);

        } else if (station == 4439) {
            console.log(obj);

        }
    });
}






















// const filter = (dataAPI) => {
//     console.log('const filter = (dataAPI)');

//     let dataObject = [];

//     for (let i = 0; i < dataAPI.length; i++) {
//         let aod = parseFloat(dataAPI[i]["aod"]).toFixed(3);
//         let date = filter_date(dataAPI[i]["date"]);
//         let time = dataAPI[i]["time"].slice(0, 5);
//         let image_name = dataAPI[i]["image_name"];
//         let image_url = `https://www-old.cmuccdc.org/uploads/cam/${image_name}`;

//         let Object = {
//             aod: aod,
//             date: date,
//             time: time,
//             image_name: image_name,
//             image_url: image_url
//         };

//         dataObject.push(Object);

//     }
//     return lastupdate(dataObject);

// }


// const filter_date = (dataAPI) => {
//     console.log('const filter_date = (dataAPI)');

//     let dateObj = new Date(dataAPI);
//     dateObj.setHours(dateObj.getHours() + 7);
//     let day = dateObj.getUTCDate();
//     let month = dateObj.getUTCMonth() + 1;
//     let year = dateObj.getUTCFullYear() + 543;
//     let formattedDate = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}/${year}`;

//     return formattedDate
// }



// const lastupdate = (dataObject) => {

//     console.log(dataObject);


//     for (let i = 0; i < dataAPI.length; i++) {


//     }














// }







