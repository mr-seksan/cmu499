const { DatePicker, Space } = antd;
const { useState } = React;
const { RangePicker } = DatePicker;

let globalData;
document.addEventListener('DOMContentLoaded', async function () {

    await aod_hour_API();

    if (globalData && globalData.length > 0) {


        if (globalData[0].status === 'empty') {
            chart_hour(globalData);
        } else {
            chart_hour(globalData);
            widgets(globalData);
        }
    } else {
        console.error('globalData is empty or undefined');
    }

    let aod_day = await aod_dayily_API();
    chart_day(aod_day);


    dropdown();

    datePicker_chart_hour();
    datePicker_chart_daily()
});




const datePicker_chart_hour = () => {
    let dateobj = '';

    const onChange = (date, dateString) => {
        dateobj = dateString;
        checkAndSendToAPI();
    };

    const checkAndSendToAPI = async () => {
        const formattedDate = moment(dateobj, "YYYY-MM-DD");
        if (formattedDate.isValid()) {
            datepicker(formattedDate._i);
        }
    };

    const disabledDate = (current) => {
        return current && current > moment().endOf('day');
    };

    const App = () => (
        React.createElement(Space, { direction: "vertical", size: "large" },
            React.createElement(DatePicker, {
                onChange: onChange,
                format: "YYYY-MM-DD",
                placeholder: "วันที่",
                disabledDate: disabledDate
            })
        )
    );

    ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App));
};



const datePicker_chart_daily = async () => {

    let dateobj = {};

    const onChange_Start = (date, dateString) => {
        dateobj.datestart = dateString;
        // console.log("Start Date: ", dateString);
        // console.log(typeof dateString);


        checkAndSendToAPI();
    };

    const onChange_End = (date, dateString) => {
        dateobj.dateend = dateString;
        // console.log("End Date: ", dateString);


        checkAndSendToAPI();
    };

    const checkAndSendToAPI = async () => {
        if (dateobj.datestart && dateobj.dateend) {


            const startDate = moment(dateobj.datestart, "YYYY-MM-DD");
            const endDate = moment(dateobj.dateend, "YYYY-MM-DD");


            if (endDate.isSameOrAfter(startDate, 'day')) {
                console.log(dateobj);
                let aod = await aod_day_API(dateobj);
                let check = await empty_day(aod);
                let aod_day = await convert_date_format(check);
                chart_day(aod_day);

            } else {
                console.log("End date must be after start date.");
            }
        }
    };

    const disabledDate = (current) => {
        return current && current > moment().endOf('day');
    };

    const App_Start = () => (
        React.createElement(Space, { direction: "vertical", size: "large" },
            React.createElement(DatePicker, {
                onChange: onChange_Start,
                format: "YYYY-MM-DD",
                placeholder: "เริ่มต้น",
                disabledDate: disabledDate
            })
        )
    );

    const App_End = () => (
        React.createElement(Space, { direction: "vertical", size: "large" },
            React.createElement(DatePicker, {
                onChange: onChange_End,
                format: "YYYY-MM-DD",
                placeholder: "สิ้นสุด",
                disabledDate: disabledDate
            })
        )
    );

    ReactDOM.createRoot(document.getElementById('datePicker-Start')).render(React.createElement(App_Start));
    ReactDOM.createRoot(document.getElementById('datePicker-End')).render(React.createElement(App_End));
};








const handleClick = (event) => {
    event.preventDefault();


    const value = event.target.getAttribute('data-value');
    const text = event.target.textContent;


    const summaryElement = document.getElementById('dropdown-summary');
    summaryElement.textContent = text;


    const detailsElement = document.getElementById('dropdown-details');
    detailsElement.removeAttribute('open');
}







const showLoadingScreen = () => {
    document.getElementById('loading-screen').style.display = 'flex';
    setTimeout(hideLoadingScreen, 1000);
}
const hideLoadingScreen = () => {
    document.getElementById('loading-screen').style.display = 'none';
}

window.addEventListener('load', function () {
    showLoadingScreen();
});

const dropdown = () => {
    const toggleButton = document.getElementById('dropdown-toggle');
    const dropdownMenu = document.getElementById('dropdown-menu');
    const iconPath = document.getElementById('icon-path');

    toggleButton.addEventListener('click', function (event) {
        event.stopPropagation();
        dropdownMenu.classList.toggle('hidden');
        if (dropdownMenu.classList.contains('hidden')) {
            iconPath.setAttribute('d', 'M4 6h16M4 12h16M4 18h16');
        } else {
            iconPath.setAttribute('d', 'M6 18 18 6M6 6l12 12');
        }
    });

    document.addEventListener('click', function (event) {
        if (!dropdownMenu.contains(event.target) && !toggleButton.contains(event.target)) {
            dropdownMenu.classList.add('hidden');
            iconPath.setAttribute('d', 'M4 6h16M4 12h16M4 18h16');
        }
    });
}

const checkdate = () => {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const format = `${year}-${month}-${day}`
    return format;
}

const checkHour = () => {
    const date = new Date();
    const hour = date.getHours();
    return hour;
}


const aod_day_API = async (dateobject) => {
    const { datestart, dateend } = dateobject
    console.log(datestart);
    console.log(dateend);

    try {
        const station = 106;
        const url = `http://localhost:3000/api/aod/avg/${station}/${datestart}/${dateend}`;
        const response = await axios.get(url);

        if (response.status === 200) {
            const resultAPI = response.data

            let message_succeed = { 'date': ' ', 'message': 'aod_day_API_200' }
            Toast(message_succeed)

            return resultAPI;
        }

    } catch (error) {
        let message_close = { 'date': ' ', 'message': 'aod_day_API_404' }
        Toast(message_close)

        return nulldata;
    }
}

const aod_hour_API = async (date) => {

    if (typeof date === 'string') {
        date = date;
    } else {
        date = checkdate();
    }

    try {
        const station = 106;
        const url = `http://localhost:3000/api/select/${date}/${station}`;
        const response = await axios.get(url);

        if (response.status === 200) {
            const resultAPI = response.data
            convert_month(resultAPI)
            convert_yearth(resultAPI)
            convert_remark(resultAPI)

            let message_succeed = { 'date': date, 'message': 'aod_hour_API_200' }
            Toast(message_succeed)


            globalData = resultAPI;
            // console.log(globalData);
            return resultAPI;
        }

    } catch (error) {
        let message_close = { 'date': date, 'message': 'aod_hour_API_404' }
        Toast(message_close)

        let nulldata = empty_hour();
        globalData = nulldata;

        return nulldata;
    }
}

const aod_dayily_API = async (date) => {
    // console.log('-> aod_hour_API: date == ', date);

    if (typeof date === 'string') {
        date = date;
    } else {
        date = checkdate();
    }

    try {
        const station = 106;
        const url = `http://localhost:3000/api/aod/${station}/avg/daily`;
        const response = await axios.get(url);



        if (response.status === 200) {
            const resultAPI = response.data
            const data = await convert_date_format(resultAPI);

            // let message_succeed = { 'date': date, 'message': 'succeed' }
            // Toast(message_succeed)


            return data;
        }

    } catch (error) {
        // let message_close = { 'date': date, 'message': 'close' }
        // Toast(message_close)

        return nulldata;
    }
}

// ---------------------------------  convert_remark  --------------------------------- //
const convert_remark = async (data) => {

    try {
        if (Array.isArray(data)) {
            data.forEach(item => {
                if (item.aod !== null && item.aod !== undefined) {
                    let aod = item.aod;

                    if (aod >= 1 && aod < 50) {
                        item.remarken = 'Good';
                        item.remarkth = 'คุณภาพอากาศดีมาก';
                        item.color = '#58e30e';
                    } else if (aod >= 51 && aod < 100) {
                        item.remarken = 'Moderate';
                        item.remarkth = 'คุณภาพอากาศปานกลาง';
                        item.color = '#FCDC2A';
                    } else if (aod >= 100 && aod < 150) {
                        item.remarken = 'Unhealthy for Sensitive Groups';
                        item.remarkth = 'เริ่มส่งผลกระทบต่อกลุ่มเสี่ยง';
                        item.color = '#FF9800';
                    } else if (aod >= 150 && aod < 200) {
                        item.remarken = 'Unhealthy';
                        item.remarkth = 'ส่งผลกระทบต่อสุขภาพ';
                        item.color = '#FF0303';
                    } else if (aod >= 200 && aod < 300) {
                        item.remarken = 'Very Unhealthy';
                        item.remarkth = 'ส่งผลกระทบต่อสุขภาพอย่างมาก';
                        item.color = '#874CCC';
                    } else if (aod >= 300) {
                        item.remarken = 'Hazardous';
                        item.remarkth = 'อันตราย';
                        item.color = '#8E3E63';
                    } else {
                        item.remarken = ' ';
                        item.remarkth = ' ';
                        item.color = '#fff';
                    }
                    return data
                }
            });

        } else {
            console.error("Input data is not an array or object");
            return data;

        }

    } catch (error) {
        console.error("Error", error);
        return data;
    }

};

// ---------------------------------  convert_month  --------------------------------- //
const convert_month = async (data) => {

    try {
        if (Array.isArray(data)) {
            data.forEach(item => {

                if (item.date !== null && item.date !== undefined) {
                    let month = item.date.split('-')[1];

                    if (month === '01') {
                        return item.month = 'มกราคม'

                    } else if (month === '02') {
                        return item.month = 'กุมภาพันธ์'

                    } else if (month === '03') {
                        return item.month = 'มีนาคม'

                    } else if (month === '04') {
                        return item.month = 'เมษายน'

                    } else if (month === '05') {
                        return item.month = 'พฤษภาคม'

                    } else if (month === '06') {
                        return item.month = 'มิถุนายน'

                    } else if (month === '07') {
                        return item.month = 'กรกฎาคม'

                    } else if (month === '08') {
                        return item.month = 'สิงหาคม'

                    } else if (month === '09') {
                        return item.month = 'กันยายน'

                    } else if (month === '10') {
                        return item.month = 'ตุลาคม'

                    } else if (month === '11') {
                        return item.month = 'พฤศจิกายน'

                    } else if (month === '12') {
                        return item.month = 'ธันวาคม'
                    }
                    return data
                }
            });

        } else {
            console.error("Input data is not an array or object");
            return data;

        }

    } catch (error) {
        console.error("Error", error);
        return data;
    }

};

// ---------------------------------  convert_yearth  --------------------------------- //
const convert_yearth = async (data) => {

    try {

        data.forEach(item => {

            let year = item.date.split('-')[0];
            let yearth = parseInt(year, 10) + 543;
            result = item.yearth = yearth;
            return result;

        })

    } catch (error) {
        console.error("Error", error);
        return data;
    }
}

// ------------------------------------  widgets  ------------------------------------- //
const widgets = async (data) => {
    try {
        let last_data;
        if (data.length > 0) {
            last_data = data[data.length - 1];
        } else {
            last_data = data;
        }

        if (last_data) {
            let box_1_image = document.getElementById('box-1-image');
            box_1_image.innerHTML = `
                <img src="https://www-old.cmuccdc.org/uploads/cam/${last_data.image_name}" alt=""/>
                <div class="nav-button prev" id="previous">«</div>
                <div class="nav-button next" id="next">»</div>
            `;

            let stat_title = document.getElementById('stat-title');
            stat_title.innerHTML = `ค่าฝุ่นละอองลอย (AOD)`;

            let stat_value = document.getElementById('stat-value');
            stat_value.innerHTML = `<div class="stat-value" style="color: ${last_data.color}; text-shadow: 0 0 2px ${last_data.color};">${last_data.aod.toFixed(2)}</div>`;

            let stat_desc1 = document.getElementById('stat-desc1');
            stat_desc1.innerHTML = `<div class="stat-desc stat-desc1" style="color: ${last_data.color}; text-shadow: 0 0 2px ${last_data.color};">${last_data.remarken}</div>`;

            let stat_desc2 = document.getElementById('stat-desc2');
            stat_desc2.innerHTML = `วันที่ ${last_data.date.split('-')[2]} ${last_data.month} ${last_data.yearth} เวลา ${last_data.time} น. <br> มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา`;

            document.getElementById('previous').addEventListener('click', (event) => checkevent(event));
            document.getElementById('next').addEventListener('click', (event) => checkevent(event));
        } else {
            console.warn('No valid data found');
        }
    } catch (error) {
        console.error("Error processing data:", error);
    }
}



// -----------------------------------  chart_hour  ----------------------------------- //
const chart_hour = async (data) => {
    try {
        const dataMap = new Map(data.map(item => [item.time, item]));

        const chartElement = document.getElementById('chart1');
        if (!chartElement) {
            console.error('Element with id "chart1" not found.');
            return;
        }

        const myChart = echarts.init(chartElement);

        const chartData = data.map(item => ({
            time: item.time,
            aod: parseFloat(item.aod)
        }));

        const option = {
            animationDuration: 3000,
            animationEasing: 'quadraticOut',
            tooltip: {
                trigger: 'axis',
                axisPointer: { type: 'cross', label: { backgroundColor: '#090910' } },
            },
            legend: { data: ['AOD'] },
            toolbox: {
                show: true,
                feature: {
                    dataView: { show: true, readOnly: true },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: false },
                    saveAsImage: { show: true }
                }
            },
            title: {
                text: '',
                textStyle: {
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 20,
                    fontWeight: 'bold',
                    color: '#333'
                }
            },
            xAxis: {
                type: 'category',
                data: chartData.map(item => item.time),
                name: 'Time',
                nameLocation: 'middle',
                nameGap: 30,
                boundaryGap: false,
                axisLabel: {
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 14,
                    color: '#3C4048'
                },
                nameTextStyle: {
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 14,
                    color: '#3C4048'
                },
                axisLine: { lineStyle: { color: '#3C4048' } },
                axisTick: { show: true },
                splitLine: { show: false }
            },
            yAxis: {
                type: 'value',
                name: 'AOD',
                nameGap: 30,
                axisLabel: {
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 14,
                    color: '#3C4048'
                },
                nameTextStyle: {
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 14,
                    color: '#3C4048'
                },
                axisLine: { lineStyle: { color: '#3C4048' } },
                axisTick: { show: true },
                splitLine: {
                    show: true,
                    lineStyle: {
                        color: '#ddd',
                        width: 1,
                        type: 'dashed',
                        opacity: 100,
                    }
                }
            },
            grid: { top: 50, right: 50, bottom: 50, left: 50, containLabel: true },
            series: [{
                name: 'AOD',
                type: 'line',
                data: chartData.map(item => item.aod),
                smooth: false,
                color: '#F4CE14',
                symbol: 'roundRect',
                symbolSize: 6,
                itemStyle: { color: '#7BC9FF' },
                lineStyle: { width: 3, type: 'solid' },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: 'rgb(123, 201, 255, 0.95)' },
                        { offset: 1, color: 'rgb(123, 201, 255, 0.05)' }
                    ])
                },
                label: {
                    show: true,
                    position: 'top',
                    color: '#FFFFFF',
                    formatter: '{c}',
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 14,
                    fontWeight: 'bold',
                    backgroundColor: '#7BC9FF',
                    borderRadius: 15,
                    padding: [3, 5, 0, 5],
                    lineHeight: 20,
                },
                emphasis: { focus: 'series' },
                tooltip: {
                    textStyle: { fontFamily: 'Noto Sans Thai, sans-serif', fontSize: 12 },
                    valueFormatter: value => (Number(value)).toFixed(2)
                },
                markLine: {
                    data: [
                        {
                            type: 'average',
                            name: 'Avg'
                        }
                    ],
                    lineStyle: {
                        color: '#7BC9FF',
                        width: 1.5
                    },
                    label: {
                        show: true,
                        position: 'end',
                        formatter: '{c}',
                        color: '#000000',
                        fontFamily: 'Noto Sans Thai, sans-serif',
                        fontSize: 13,
                        padding: [0, 0, 0, 5]
                    },
                    symbol: ['roundRect', 'roundRect'],
                    symbolSize: [10, 10]
                }
            }]
        };

        myChart.setOption(option);

        window.addEventListener('resize', () => myChart.resize());

        myChart.on('mousemove', function (params) {
            if (params.value) {
                const time = params.name;
                const data = dataMap.get(time);

                let box_1_image = document.getElementById('box-1-image');
                if (typeof data.image_name == 'undefined') {
                    box_1_image.innerHTML = ``;
                } else {
                    box_1_image.innerHTML = `
                        <img src="https://www-old.cmuccdc.org/uploads/cam/${data.image_name}" alt=""/>
                        <div class="nav-button prev" id="previous">«</div>
                        <div class="nav-button next" id="next">»</div>
                    `;

                    const previousButton = document.getElementById('previous');
                    const nextButton = document.getElementById('next');

                    if (previousButton) {
                        previousButton.addEventListener('click', (event) => checkevent(event));
                    }

                    if (nextButton) {
                        nextButton.addEventListener('click', (event) => checkevent(event));
                    }
                }

                let stat_value = document.getElementById('stat-value');
                stat_value.innerHTML = `<div class="stat-value" style="color: ${data.color}; text-shadow: 0 0 2px ${data.color};">${data.aod.toFixed(2)}</div>`

                let stat_desc1 = document.getElementById('stat-desc1');
                stat_desc1.innerHTML = `<div class="stat-desc stat-desc1" style="color: ${data.color}; text-shadow: 0 0 2px ${data.color};">${data.remarken}</div>`

                let stat_desc2 = document.getElementById('stat-desc2');
                stat_desc2.innerHTML = `วันที่ ${data.date.split('-')[2]} ${data.month} ${data.yearth} เวลา ${data.time} น. <br> มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา`
            }
        });

    } catch (error) {
        console.error("Error processing data:", error);
    }
}

// -----------------------------------  datepicker  ----------------------------------- //
let currentPosition = -1;
let dateFromDatepicker = null;
let buttonsDisabled = false;

const datepicker = async (date) => {
    // console.log(event);
    // const { value } = event.target;
    // const date = value;
    console.log(date);


    try {
        const aod_date = await aod_hour_API(date);
        if (aod_date === null) {
            // buttonsDisabled = true;
            // document.getElementById('previous').classList.add('btn-disabled');
            // document.getElementById('next').classList.add('btn-disabled');
        } else {


            console.log(aod_date);

            if (globalData && globalData.length > 0) {


                if (globalData[0].status === 'empty') {
                    chart_hour(globalData);

                    buttonsDisabled = true;
                    document.getElementById('previous').classList.add('btn-disabled');
                    document.getElementById('next').classList.add('btn-disabled');

                } else {
                    chart_hour(globalData);
                    widgets(globalData);

                    currentPosition = -1;
                    dateFromDatepicker = date;
                    buttonsDisabled = false;
                    document.getElementById('previous').classList.remove('btn-disabled');
                    document.getElementById('next').classList.remove('btn-disabled');
                }
            } else {
                console.error('globalData is empty or undefined');
            }

        }
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}



// -----------------------------------  checkevent1  ----------------------------------- //
const checkevent = async (event, date = null) => {
    if (buttonsDisabled) {
        return;
    }

    // const data = await aod_hour_API(date);
    const data = globalData;
    if (data === null) {
        // buttonsDisabled = true;
        // document.getElementById('previous').classList.add('btn-disabled');
        // document.getElementById('next').classList.add('btn-disabled');
        return;
    }

    const id = event.target.id;

    if (currentPosition === -1) {
        currentPosition = data.length - 1;
    }

    if (id === 'previous') {
        currentPosition = (currentPosition > 0) ? currentPosition - 1 : data.length - 1;
    } else if (id === 'next') {
        currentPosition = (currentPosition < data.length - 1) ? currentPosition + 1 : 0;
    }

    // console.log(currentPosition);
    // console.log(data[currentPosition]);
    widgets(data[currentPosition]);
}



// ----------------------------  buttom_next_previous  ------------------------------- //
// const buttom_next_previous = (data) => {

//     if (data.message == 'close') {
//         buttonsDisabled = true;
//         document.getElementById('previous').classList.add('btn-disabled');
//         document.getElementById('next').classList.add('btn-disabled');;

//     } else if (data.message == 'open') {

//     }

// }

// -----------------------------------  Toast  ----------------------------------- //


let toastTimeout;
const Toast = async (data) => {
    try {
        let toast = document.querySelector('.custom-toast');

        if (data && data.message) {
            if (data.message === 'aod_hour_API_404') {

                const custom_toast = document.querySelector('.custom-toast');
                if (custom_toast) {
                    custom_toast.style.borderLeft = `25px solid #ED2B2A`;
                }

                const custom_toast_progress = document.querySelector('.custom-toast-progress');
                if (custom_toast_progress) {
                    custom_toast_progress.style.backgroundColor = `#ED2B2A`;
                }

                // buttom_next_previous(data)

                let formattedData = await convert_date_format(data);
                let custom_toast_content = document.querySelector('.custom-toast-content');
                custom_toast_content.innerHTML = `
                <div class="custom-toast-svg" style="color: #ED2B2A;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-10"> <path fill-rule="evenodd"
                            d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm-1.72 6.97a.75.75 0 1 0-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 1 0 1.06 1.06L12 13.06l1.72 1.72a.75.75 0 1 0 1.06-1.06L13.06 12l1.72-1.72a.75.75 0 1 0-1.06-1.06L12 10.94l-1.72-1.72Z"
                            clip-rule="evenodd" />
                    </svg>
                </div>

                <div class="message">
                    <div class="text text-1" style="color: #ED2B2A;">ขออภัย</div>
                    <div class="text text-2">ไม่พบข้อมูลในวันที่ ${formattedData.dateth} </div>
                    <button id="close" class="close" onclick="closeToast()">&times;</button>
                </div>

                `;



            } else if (data.message === 'aod_hour_API_200') {

                const custom_toast = document.querySelector('.custom-toast');
                if (custom_toast) {
                    custom_toast.style.borderLeft = `25px solid #06D001`;
                }

                const custom_toast_progress = document.querySelector('.custom-toast-progress');
                if (custom_toast_progress) {
                    custom_toast_progress.style.backgroundColor = `#06D001`;
                }

                let formattedData = await convert_date_format(data);
                let custom_toast_content = document.querySelector('.custom-toast-content');
                custom_toast_content.innerHTML = `
                <div class="custom-toast-svg" style="color: #06D001;">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-10">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                    </svg>

                </div>

                <div class="message">
                    <div class="text text-1" style="color: #06D001;">สำเร็จ</div>
                    <div class="text text-2">พบข้อมูลวันที่ ${formattedData.dateth} </div>
                    <button id="close" class="close" onclick="closeToast()">&times;</button>
                </div>

                `;

            } else if (data.message === 'aod_day_API_200') {

                const custom_toast = document.querySelector('.custom-toast');
                if (custom_toast) {
                    custom_toast.style.borderLeft = `25px solid #06D001`;
                }

                const custom_toast_progress = document.querySelector('.custom-toast-progress');
                if (custom_toast_progress) {
                    custom_toast_progress.style.backgroundColor = `#06D001`;
                }

                let formattedData = await convert_date_format(data);
                let custom_toast_content = document.querySelector('.custom-toast-content');
                custom_toast_content.innerHTML = `
                <div class="custom-toast-svg" style="color: #06D001;">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-10">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                    </svg>

                </div>

                <div class="message">
                    <div class="text text-1" style="color: #06D001;">สำเร็จ</div>
                    <div class="text text-2">พบข้อมูลในช่วงเวลาดังกล่าว </div>
                    <button id="close" class="close" onclick="closeToast()">&times;</button>
                </div>

                `;

            } else if (data.message === 'aod_day_API_404') {

                const custom_toast = document.querySelector('.custom-toast');
                if (custom_toast) {
                    custom_toast.style.borderLeft = `25px solid #ED2B2A`;
                }

                const custom_toast_progress = document.querySelector('.custom-toast-progress');
                if (custom_toast_progress) {
                    custom_toast_progress.style.backgroundColor = `#ED2B2A`;
                }

                // buttom_next_previous(data)

                let formattedData = await convert_date_format(data);
                let custom_toast_content = document.querySelector('.custom-toast-content');
                custom_toast_content.innerHTML = `
                <div class="custom-toast-svg" style="color: #ED2B2A;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-10"> <path fill-rule="evenodd"
                            d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm-1.72 6.97a.75.75 0 1 0-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 1 0 1.06 1.06L12 13.06l1.72 1.72a.75.75 0 1 0 1.06-1.06L13.06 12l1.72-1.72a.75.75 0 1 0-1.06-1.06L12 10.94l-1.72-1.72Z"
                            clip-rule="evenodd" />
                    </svg>
                </div>

                <div class="message">
                    <div class="text text-1" style="color: #ED2B2A;">ขออภัย</div>
                    <div class="text text-2">ไม่พบข้อมูลในช่วงเวลาดังกล่าว </div>
                    <button id="close" class="close" onclick="closeToast()">&times;</button>
                </div>

                `;



            }









            toast.classList.add('active');
            clearTimeout(toastTimeout);


            toastTimeout = setTimeout(() => {
                toast.classList.remove('active');
            }, 3000);

        } else {
            throw new Error("Invalid data format");
        }

    } catch (error) {
        console.error(error);
    }
}



// ---------------------------------  closeToast  --------------------------------- //
const closeToast = () => {
    const toast = document.querySelector('.custom-toast');
    toast.classList.remove('active');
    clearTimeout(toastTimeout);
}

// ---------------------------  convert_date_format  ------------------------------ //
const convert_date_format = async (data) => {
    try {

        const formatDate = (dateStr) => {
            let date = new Date(dateStr);
            return date.toLocaleDateString('en-GB');
        };

        if (Array.isArray(data)) {
            return data.map(entry => {
                if (entry.date) {
                    return { ...entry, dateth: formatDate(entry.date) };
                } else {
                    console.warn("Entry does not have a date property:", entry);
                    return entry;
                }
            });
        }

        else if (typeof data === 'object' && data !== null) {
            if (data.date) {
                return { ...data, dateth: formatDate(data.date) };
            } else {
                console.warn("Object does not have a date property:", data);
                return data;
            }
        }
        else {
            throw new Error("Data must be an array or an object");
        }

    } catch (error) {
        console.error(error);
        return;
    }
}

// ---------------------------------  empty  --------------------------------- //
const empty_hour = () => {
    let station = 106;
    let data = [];
    let date = checkdate();
    let hr = checkHour();

    for (let hour = 6; hour <= hr; hour++) {
        let time = hour.toString().padStart(2, '0') + ':00';
        data.push({ station: station, date: date, time: time, aod: Number(0), status: 'empty' });
    }
    return data
}


const empty_day = (data) => {
    if (data.length === 0) return [];

    // ค้นหาวันเริ่มต้นและวันสิ้นสุด
    let datestart = new Date(data[0].date);
    let datesend = new Date(data[data.length - 1].date);

    // ฟังก์ชันเพื่อเพิ่มวัน
    const addDays = (date, days) => {
        const result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
    };

    // สร้างรายชื่อของทุกวันในช่วงวันที่ที่กำหนด
    let currentDate = datestart;
    let dateList = [];
    while (currentDate <= datesend) {
        dateList.push(currentDate.toISOString().split('T')[0]);
        currentDate = addDays(currentDate, 1);
    }

    // แปลงข้อมูลจาก API เป็นวัตถุที่ใช้ตรวจสอบ
    let dataMap = new Map();
    data.forEach(item => {
        dataMap.set(item.date, {
            date: item.date,
            avg_aod: Number(item.avg_aod),
            status: 'present'
        });
    });

    // สร้างข้อมูลทั้งหมดรวมถึงวันที่ที่ไม่มีข้อมูล
    let result = dateList.map(date => {
        return dataMap.get(date) || {
            date: date,
            avg_aod: 0,
            status: 'empty'
        };
    });
    console.log(result);
    return result;
};
















const chart_day = async (data) => {
    try {

        // console.log(data);

        const chartElement = document.getElementById('chart2');
        if (!chartElement) {
            console.error('Element with id "chart1" not found.');
            return;
        }

        const myChart = echarts.init(chartElement);

        const chartData = data.map(item => ({
            date: item.dateth,
            aod: parseFloat(item.avg_aod).toFixed(2)
        }));

        const option = {
            animationDuration: 3000,
            animationEasing: 'quadraticOut',
            tooltip: {
                trigger: 'axis',
                axisPointer: { type: 'cross', label: { backgroundColor: '#090910' } },
            },
            legend: { data: ['AOD'] },
            toolbox: {
                show: true,
                feature: {
                    dataView: { show: true, readOnly: true },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: false },
                    saveAsImage: { show: true }
                }
            },
            title: {
                text: '',
                textStyle: {
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 20,
                    fontWeight: 'bold',
                    color: '#333'
                }
            },
            xAxis: {
                type: 'category',
                data: chartData.map(item => item.date),
                name: 'Date',
                nameLocation: 'middle',
                nameGap: 30,
                boundaryGap: false,
                axisLabel: {
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 14,
                    color: '#3C4048'
                },
                nameTextStyle: {
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 14,
                    color: '#3C4048'
                },
                axisLine: { lineStyle: { color: '#3C4048' } },
                axisTick: { show: true },
                splitLine: { show: false }
            },
            yAxis: {
                type: 'value',
                name: 'AOD',
                nameGap: 30,
                axisLabel: {
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 14,
                    color: '#333'
                },
                nameTextStyle: {
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 14,
                    color: '#333'
                },
                axisLine: { lineStyle: { color: '#000' } },
                axisTick: { show: true },
                splitLine: {
                    show: true,
                    lineStyle: {
                        color: '#ddd',
                        width: 1,
                        type: 'dashed',
                        opacity: 100,
                    }
                }
            },
            grid: { top: 50, right: 50, bottom: 50, left: 50, containLabel: true },
            series: [{
                name: 'AOD',
                type: 'line',
                data: chartData.map(item => item.aod),
                smooth: false,
                color: '#FFB1B1',
                symbol: 'roundRect',
                symbolSize: 6,
                itemStyle: { color: '#FFB1B1' },
                lineStyle: { width: 3, type: 'solid' },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: 'rgb(255, 177, 177, 0.95)' },
                        { offset: 1, color: 'rgb(255, 177, 177, 0.05)' }
                    ])
                },
                label: {
                    show: true,
                    position: 'top',
                    color: '#FFFFFF',
                    formatter: '{c}',
                    fontFamily: 'Noto Sans Thai, sans-serif',
                    fontSize: 14,
                    fontWeight: 'bold',
                    backgroundColor: '#FFB1B1',
                    borderRadius: 15,
                    padding: [3, 5, 0, 5],
                    lineHeight: 20,
                },
                emphasis: { focus: 'series' },
                tooltip: {
                    textStyle: { fontFamily: 'Noto Sans Thai, sans-serif', fontSize: 12 },
                    valueFormatter: value => value
                },
                markLine: {
                    data: [
                        {
                            type: 'average',
                            name: 'Avg'
                        }
                    ],
                    lineStyle: {
                        color: '#FFB1B1',
                        width: 1.5
                    },
                    label: {
                        show: true,
                        position: 'end',
                        formatter: '{c}',
                        color: '#000000',
                        fontFamily: 'Noto Sans Thai, sans-serif',
                        fontSize: 13,
                        padding: [0, 0, 0, 5]
                    },
                    symbol: ['roundRect', 'roundRect'],
                    symbolSize: [10, 10]
                }

            }]
        };

        myChart.setOption(option);

        window.addEventListener('resize', () => myChart.resize());


    } catch (error) {
        console.error("Error processing data:", error);
    }
}












































// const display = async (data) => {
//     try {

//         // console.log('-> display', data);


//         if (!data || data.length === 0) {
//             console.error("No data available for chart.");
//             return;
//         }

//         // let func_convert_remark = await convert_remark(data)
//         // console.log(func_convert_remark);
//         let def_filter_remark = filter_remark(data);
//         let time = data['time']
//         let day = data.date.split('-')[2];
//         let def_filter_month = filter_month(data);
//         let def_filter_year = filter_year(data);

//         // console.log(data);


//         if (typeof data.image_name == 'undefined') {
//             let box_1_image = document.getElementById('box-1-image');
//             box_1_image.innerHTML = ``
//         } else {
//             let box_1_image = document.getElementById('box-1-image');
//             box_1_image.innerHTML = `<img src="https://www-old.cmuccdc.org/uploads/cam/${data.image_name}" alt="" />`
//         }

//         let stat_title = document.getElementById('stat-title');
//         stat_title.innerHTML = `ค่าฝุ่นละอองลอย (AOD)`

//         let stat_value = document.getElementById('stat-value');
//         stat_value.innerHTML = `<div class="stat-value" style="color: ${data.color}">${data.aod.toFixed(2)}</div>`

//         let stat_desc1 = document.getElementById('stat-desc1');
//         // stat_desc1.innerHTML = `${def_filter_remark['remark']}`
//         stat_desc1.innerHTML = `<div class="stat-desc stat-desc1" style="color: ${data.color}">${def_filter_remark['remark']}</div>`

//         let stat_desc2 = document.getElementById('stat-desc2');
//         stat_desc2.innerHTML = `วันที่ ${day} ${def_filter_month['month']} ${def_filter_year['year']} เวลา ${time} น. <br> มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา`



//     } catch (error) {
//         console.error("Error processing data:", error);
//     }

// }


// const chart1 = async (data) => {
//     try {

//         // console.log(data);
//         // console.log(typeof data);

//         // let func_convert_remark = await convert_remark(data)
//         // console.log(func_convert_remark);



//         if (data === null) {
//             // console.log('5555');
//             var timeArray = [];
//             for (let hour = 6; hour <= 18; hour++) {
//                 let time = hour.toString().padStart(2, '0') + ':00';
//                 timeArray.push({ time: time, aod: 0 });
//             }
//             var data = timeArray;

//         }



//         const lastItem = data[data.length - 1];
//         // display(lastItem)

//         // console.log('chart1', data);


//         if (data[0] == undefined || data === null) {
//             var timeArray = [];
//             for (let hour = 6; hour <= 18; hour++) {
//                 let time = hour.toString().padStart(2, '0') + ':00';
//                 timeArray.push({ time: time, aod: 0 });
//             }
//             var data = timeArray;

//         }
//         // console.log(timeArray);


//         const dataMap = new Map(data.map(item => [item.time, item]));

//         const chartElement = document.getElementById('chart1');
//         if (!chartElement) {
//             console.error('Element with id "chart1" not found.');
//             return;
//         }

//         const myChart = echarts.init(chartElement);

//         const chartData = data.map(item => ({
//             time: item.time,
//             aod: parseFloat(item.aod)
//         }));

//         const option = {
//             animationDuration: 3000,
//             animationEasing: 'quadraticOut',
//             tooltip: {
//                 trigger: 'axis',
//                 axisPointer: { type: 'cross', label: { backgroundColor: '#090910' } },
//             },
//             legend: { data: ['AOD'] },
//             toolbox: {
//                 show: true,
//                 feature: {
//                     dataView: { show: true, readOnly: true },
//                     magicType: { show: true, type: ['line', 'bar'] },
//                     restore: { show: false },
//                     saveAsImage: { show: true }
//                 }
//             },
//             title: {
//                 text: '',
//                 textStyle: {
//                     fontFamily: 'Noto Sans Thai, sans-serif',
//                     fontSize: 20,
//                     fontWeight: 'bold',
//                     color: '#333'
//                 }
//             },
//             xAxis: {
//                 type: 'category',
//                 data: chartData.map(item => item.time),
//                 name: 'Time',
//                 nameLocation: 'middle',
//                 nameGap: 30,
//                 boundaryGap: false,
//                 axisLabel: {
//                     fontFamily: 'Noto Sans Thai, sans-serif',
//                     fontSize: 14,
//                     color: '#3C4048'
//                 },
//                 nameTextStyle: {
//                     fontFamily: 'Noto Sans Thai, sans-serif',
//                     fontSize: 14,
//                     color: '#3C4048'
//                 },
//                 axisLine: { lineStyle: { color: '#3C4048' } },
//                 axisTick: { show: true },
//                 splitLine: { show: false }
//             },
//             yAxis: {
//                 type: 'value',
//                 name: 'AOD',
//                 nameGap: 30,
//                 axisLabel: {
//                     fontFamily: 'Noto Sans Thai, sans-serif',
//                     fontSize: 14,
//                     color: '#3C4048'
//                 },
//                 nameTextStyle: {
//                     fontFamily: 'Noto Sans Thai, sans-serif',
//                     fontSize: 14,
//                     color: '#3C4048'
//                 },
//                 axisLine: { lineStyle: { color: '#3C4048' } },
//                 axisTick: { show: true },
//                 splitLine: {
//                     show: true,
//                     lineStyle: {
//                         color: '#ddd',
//                         width: 1,
//                         type: 'dashed',
//                         opacity: 100,
//                     }
//                 }
//             },
//             grid: { top: 50, right: 50, bottom: 50, left: 50, containLabel: true },
//             series: [{
//                 name: 'AOD',
//                 type: 'line',
//                 data: chartData.map(item => item.aod),
//                 smooth: false,
//                 color: '#F4CE14',
//                 symbol: 'roundRect',
//                 symbolSize: 6,
//                 itemStyle: { color: '#7BC9FF' },
//                 lineStyle: { width: 3, type: 'solid' },
//                 areaStyle: {
//                     color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
//                         { offset: 0, color: 'rgb(123, 201, 255, 0.95)' },
//                         { offset: 1, color: 'rgb(123, 201, 255, 0.05)' }
//                     ])
//                 },
//                 label: {
//                     show: true,
//                     position: 'top',
//                     color: '#FFFFFF',
//                     formatter: '{c}',
//                     fontFamily: 'Noto Sans Thai, sans-serif',
//                     fontSize: 14,
//                     fontWeight: 'bold',
//                     backgroundColor: '#7BC9FF',
//                     borderRadius: 15,
//                     padding: [3, 5, 0, 5],
//                     lineHeight: 20,
//                 },
//                 emphasis: { focus: 'series' },
//                 tooltip: {
//                     textStyle: { fontFamily: 'Noto Sans Thai, sans-serif', fontSize: 12 },
//                     valueFormatter: value => (Number(value)).toFixed(2)
//                 },
//                 markLine: {
//                     data: [
//                         {
//                             type: 'average',
//                             name: 'Avg'
//                         }
//                     ],
//                     lineStyle: {
//                         color: '#7BC9FF',
//                         width: 1.5
//                     },
//                     label: {
//                         show: true,
//                         position: 'end',
//                         formatter: '{c}',
//                         color: '#000000',
//                         fontFamily: 'Noto Sans Thai, sans-serif',
//                         fontSize: 13,
//                         padding: [0, 0, 0, 5]
//                     },
//                     symbol: ['roundRect', 'roundRect'],
//                     symbolSize: [10, 10]
//                 }
//             }]
//         };

//         myChart.setOption(option);

//         window.addEventListener('resize', () => myChart.resize());

//         myChart.on('mousemove', function (params) {


//             if (params.value) {
//                 const time = params.name;
//                 const data = dataMap.get(time);
//                 // console.log(data);

//                 if (data) {

//                     document.getElementById('box-1-image').innerHTML = `< img src = "https://www-old.cmuccdc.org/uploads/cam/${data.image_name}" alt = "" /> `;
//                     document.getElementById('stat-value').innerHTML = `< div class="stat-value" style = "color: ${data.color}" > ${data.aod.toFixed(2)}</ > `;

//                     const def_filter_remark = filter_remark(data);
//                     document.getElementById('stat-desc1').innerHTML = `< div class="stat-desc stat-desc1" style = "color: ${data.color}" > ${def_filter_remark['remark']}</ > `;

//                     const day = data.date.split('-')[2];
//                     const def_filter_month = filter_month(data);
//                     const def_filter_year = filter_year(data);
//                     document.getElementById('stat-desc2').innerHTML = `วันที่ ${day} ${def_filter_month['month']} ${def_filter_year['year']} เวลา ${time} น. < br > มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา`;
//                 }
//             }
//         });

//     } catch (error) {
//         console.error("Error processing data:", error);
//     }
// }








// const convert_remark = async (data) => {
//     console.log(data);
//     console.log(typeof data);

//     try {
//         if (Array.isArray(data)) {
//             data.forEach(item => {
//                 if (item.aod !== null && item.aod !== undefined) {
//                     let aod = item.aod;

//                     if (aod >= 1 && aod < 50) {
//                         item.remarken = 'Good';
//                         item.remarkth = 'คุณภาพอากาศดีมาก';
//                         item.color = '#58e30e';
//                     } else if (aod >= 51 && aod < 100) {
//                         item.remarken = 'Moderate';
//                         item.remarkth = 'คุณภาพอากาศปานกลาง';
//                         item.color = '#FCDC2A';
//                     } else if (aod >= 100 && aod < 150) {
//                         item.remarken = 'Unhealthy for Sensitive Groups';
//                         item.remarkth = 'เริ่มส่งผลกระทบต่อกลุ่มเสี่ยง';
//                         item.color = '#FF9800';
//                     } else if (aod >= 150 && aod < 200) {
//                         item.remarken = 'Unhealthy';
//                         item.remarkth = 'ส่งผลกระทบต่อสุขภาพ';
//                         item.color = '#FF0303';
//                     } else if (aod >= 200 && aod < 300) {
//                         item.remarken = 'Very Unhealthy';
//                         item.remarkth = 'ส่งผลกระทบต่อสุขภาพอย่างมาก';
//                         item.color = '#874CCC';
//                     } else if (aod >= 300) {
//                         item.remarken = 'Hazardous';
//                         item.remarkth = 'อันตราย';
//                         item.color = '#8E3E63';
//                     } else {
//                         item.remarken = ' ';
//                         item.remarkth = ' ';
//                         item.color = '#fff';
//                     }
//                     return data
//                 }
//             });
//         } else if (typeof data === 'object' && data !== null) {
//             const { aod } = data;
//             if (aod >= 1 && aod < 50) {
//                 data.remarken = 'Good';
//                 data.remarkth = 'คุณภาพอากาศดีมาก';
//                 data.color = '#58e30e';
//             } else if (aod >= 51 && aod < 100) {
//                 data.remarken = 'Moderate';
//                 data.remarkth = 'คุณภาพอากาศปานกลาง';
//                 data.color = '#FCDC2A';
//             } else if (aod >= 100 && aod < 150) {
//                 data.remarken = 'Unhealthy for Sensitive Groups';
//                 data.remarkth = 'เริ่มส่งผลกระทบต่อกลุ่มเสี่ยง';
//                 data.color = '#FF9800';
//             } else if (aod >= 150 && aod < 200) {
//                 data.remarken = 'Unhealthy';
//                 data.remarkth = 'ส่งผลกระทบต่อสุขภาพ';
//                 data.color = '#FF0303';
//             } else if (aod >= 200 && aod < 300) {
//                 data.remarken = 'Very Unhealthy';
//                 data.remarkth = 'ส่งผลกระทบต่อสุขภาพอย่างมาก';
//                 data.color = '#874CCC';
//             } else if (aod >= 300) {
//                 data.remarken = 'Hazardous';
//                 data.remarkth = 'อันตราย';
//                 data.color = '#8E3E63';
//             } else {
//                 data.remarken = ' ';
//                 data.remarkth = ' ';
//                 data.color = '#ddd';
//             }
//             return data

//         } else {
//             console.error("Input data is not an array or object");
//             return {};
//         }







//     } catch (error) {
//         console.error("Error processing data:", error);
//         return [];
//     }
// };




// const filter_remark = (data) => {

//     data = data.aod

//     if (data < 50) {
//         return ({ 'remark': 'Good' })

//     } else if (data >= 50 && data < 100) {
//         return ({ 'remark': 'Moderate' })

//     } else if (data >= 100 && data < 150) {
//         return ({ 'remark': 'Unhealthy for Sensitive Groups' })

//     } else if (data >= 150 && data < 200) {
//         return ({ 'remark': 'Unhealthy' })

//     } else if (data >= 200 && data < 300) {
//         return ({ 'remark': 'Very Unhealthy' })

//     } else if (data >= 300) {
//         return ({ 'remark': 'Hazardous' })
//     }
// };


// const filter_month = (data) => {
//     data_number = data.date.split('-')[1]

//     if (data_number === '01') {
//         return ({ 'month': 'มกราคม' })

//     } else if (data_number === '02') {
//         return ({ 'month': 'กุมภาพันธ์' })

//     } else if (data_number === '03') {
//         return ({ 'month': 'มีนาคม' })

//     } else if (data_number === '04') {
//         return ({ 'month': 'เมษายน  ' })

//     } else if (data_number === '05') {
//         return ({ 'month': 'พฤษภาคม' })

//     } else if (data_number === '06') {
//         return ({ 'month': 'มิถุนายน' })

//     } else if (data_number === '07') {
//         return ({ 'month': 'กรกฎาคม' })

//     } else if (data_number === '08') {
//         return ({ 'month': 'สิงหาคม' })

//     } else if (data_number === '09') {
//         return ({ 'month': 'กันยายน' })

//     } else if (data_number === '10') {
//         return ({ 'month': 'ตุลาคม' })

//     } else if (data_number === '11') {
//         return ({ 'month': 'พฤศจิกายน' })

//     } else if (data_number === '12') {
//         return ({ 'month': 'ธันวาคม' })
//     }
// };


// const filter_year = (data) => {

//     let data_year = data.date.split('-')[0];
//     let year = parseInt(data_year, 10) + 543;

//     return { 'year': year };
// }























































// const aod_hour_API = async () => {
//     try {
//         const station = 106;
//         const date = checkdate();
//         const url = `http://localhost:3000/api/select/${date}/${station}`;
//         const response = await axios.get(url);
//         return response.data;

//     } catch (error) {
//         console.error("Error fetching data:", error);
//         return {};
//     }
// }





// const aod_hour_API = async (date) => {
//     const station = 106;
//     if (typeof date === 'undefined') {
//         date = checkdate();
//     } else if (typeof date === 'string') {
//         date = date;
//     }
//     try {
//         const url = `http://localhost:3000/api/select/${date}/${station}`;
//         const response = await axios.get(url);

//         console.log('-> aod_hour_API', response.status);

//         if (response.status == 200) {
//             console.log(response.data);
//             return response.data;
//         } else if (response.status == 404) {
//             console.log(response.data);
//             const func_empty = empty(station, date);
//             console.log(func_empty);
//             return func_empty
//         }
//     } catch (error) {
//         console.error("Error", error);
//         const toast = document.querySelector(".toast");
//         const progress = document.querySelector(".progress");

//         toast.classList.add("active");
//         progress.classList.add("active");

//         setTimeout(() => {
//             toast.classList.remove("active");
//         }, 5000);

//         setTimeout(() => {
//             progress.classList.remove("active");
//         }, 5300);

//         const func_empty = empty(station, date);
//         console.log(func_empty);
//         return func_empty
//     }
// }

// const empty = (station, date) => {
//     var Array = [];
//     for (let hour = 6; hour <= 18; hour++) {
//         let time = hour.toString().padStart(2, '0') + ':00';
//         Array.push({ station: station, date: date, time: time, aod: Number(0) });
//     }
//     return Array;
// }


