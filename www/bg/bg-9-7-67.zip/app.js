document.addEventListener('DOMContentLoaded', function () {
    var carto = L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '',
        subdomains: 'abcd',
        maxZoom: 20
    });

    var customIcon = L.icon({
        iconUrl: './google-maps.png',
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32]
    });

    var map = L.map('map', {
        center: [18.802830795122798, 98.95038193273236],
        zoom: 13,
        zoomControl: true,
        doubleClickZoom: false,
        scrollWheelZoom: false,
        boxZoom: false,
        keyboard: false,
        dragging: false,
        touchZoom: 'true',
        layers: [carto]
    });

    var marker_engineering = L.marker([18.795739594690353, 98.9530624508629], { icon: customIcon })
        .addTo(map)
        .on('click', async (e) => {
            try {
                let obj = lastupdateObject.filter(i => i.station == 2004)
                displayCard(obj)

            } catch (error) {
                console.log(error)
            }

        });

    var marker_rmutl = L.marker([18.809792610881917, 98.95671263406584], { icon: customIcon })
        .addTo(map)
        .on('click', async (e) => {
            try {
                let obj = lastupdateObject.filter(i => i.station == 106)
                displayCard(obj)

            } catch (error) {
                console.log(error)
            }

        });

    var marker_uniserv = L.marker([18.79417009002368, 98.9667513685618], { icon: customIcon })
        .addTo(map)
        .on('click', async (e) => {
            try {
                let obj = lastupdateObject.filter(i => i.station == 4439)
                displayCard(obj)

            } catch (error) {
                console.log(error)
            }

        });

    var marker_maehia = L.marker([18.76139615376945, 98.93185143728131], { icon: customIcon })
        .addTo(map)
        .on('click', async (e) => {
            try {
                let obj = lastupdateObject.filter(i => i.station == 6)
                displayCard(obj)

            } catch (error) {
                console.log(error)
            }

        });

    var cities = L.layerGroup([marker_engineering, marker_rmutl, marker_uniserv, marker_maehia]).addTo(map);

    var baseMaps = {
        "Carto": carto
    };

    var overlayMaps = {
        "กล้อง CCTV": cities
    };

    L.control.layers(baseMaps, overlayMaps).addTo(map);

    // function onMarkerClick(e) {
    //     var card = document.getElementById('info-card');
    //     var cardContent = document.getElementById('card-content');

    //     console.log(e.target === marker_eng);

    //     if (e.target === marker_eng) {
    //         console.log(e);
    //         cardContent.innerHTML = `
    //             <img src="./image/Cam007_20240223090003.jpg" alt="Image 1" class="card-image"/>
    //             <div class="card-text">
    //                 <div class="card-text-header">
    //                     <h2> <b> มหาวิทยาลัยเชียงใหม่ (คณะวิศวกรรมศาสตร์) </b> </h2>
    //                 </div>

    //                 <div class="card-text-desc">
    //                     <p> <b>วันที่:</b> 1/1/2567 <b>เวลา:</b> 6:00</p>
    //                     <p> <b>ค่าฝุ่นละอองลอย:</b> 20</p>
    //                 </div>
    //             </div>
    //         `;
    //     } else if (e.target === marker_rmutl) {
    //         cardContent.innerHTML = `
    //             <img src="./Cam005_20240204120002.jpg" alt="Image 2" class="card-image"/>
    //             <div class="card-text">
    //                 <div class="card-text-header">
    //                     <h2> <b> มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา </b> </h2>
    //                 </div>

    //                 <div class="card-text-desc">
    //                     <p> <b>วันที่:</b> 1/1/2567 <b>เวลา:</b> 6:00</p>
    //                     <p> <b>ค่าฝุ่นละอองลอย:</b> 20</p>
    //                 </div>
    //             </div>
    //         `;
    //     } else if (e.target === marker_uni) {
    //         cardContent.innerHTML = `
    //             <img src="./image/Cam008_20240323150003.jpg" alt="Image 4" class="card-image"/>
    //             <div class="card-text">
    //                 <div class="card-text-header">
    //                     <h2> <b> สำนักบริการวิชาการ มหาวิทยาลัยเชียงใหม่ </b> </h2>
    //                 </div>

    //                 <div class="card-text-desc">
    //                     <p> <b>วันที่:</b> 1/1/2567 <b>เวลา:</b> 6:00</p>
    //                     <p> <b>ค่าฝุ่นละอองลอย:</b> 20</p>
    //                 </div>
    //             </div>
    //         `;
    //     } else if (e.target === marker_maehia) {
    //         cardContent.innerHTML = `
    //         <img src="./image/Cam001_20240220160002.jpg" alt="Image 3" class="card-image"/>
    //         <div class="card-text">
    //                 <div class="card-text-header">
    //                     <h2> <b> มหาวิทยาลัยเชียงใหม่ (แม่เหียะ) </b> </h2>
    //                 </div>

    //                 <div class="card-text-desc">
    //                     <p> <b>วันที่:</b> 1/1/2567 <b>เวลา:</b> 6:00</p>
    //                     <p> <b>ค่าฝุ่นละอองลอย:</b> 20</p>
    //                 </div>
    //             </div>
    //         `;
    //     }

    //     card.classList.remove('hidden');
    //     document.body.classList.add('blur-background');
    // }

    document.getElementById('close-card').addEventListener('click', function () {
        document.getElementById('info-card').classList.add('hidden');
        document.body.classList.remove('blur-background');
    });

    function showLoadingScreen() {
        document.getElementById('loading-screen').style.display = 'flex';

        setTimeout(function () {
            document.getElementById('loading-screen').style.display = 'none';
        }, 1000);
    }

    window.addEventListener('load', function () {
        showLoadingScreen();
    });



});









var lastupdateObject;


const get_data_lastupdateAPI = async () => {
    const stations = [6, 106, 2004, 4439];
    try {
        const requests = stations.map(station => {
            const url = `http://localhost:3000/api/database/lastupdate/${station}`;
            return axios.get(url).then(res => res.data);
        });

        const results = await Promise.all(requests);
        lastupdateObject = results;
        widget(lastupdateObject)

    } catch (error) {
        console.error("Error fetching data:", error);
    }
}
get_data_lastupdateAPI()





const widget = (lastupdateObjects) => {

    lastupdateObjects.forEach(obj => {

        var st_rmutl = document.getElementById('st_rmutl');
        var st_engi = document.getElementById('st_engi');
        var st_maehia = document.getElementById('st_maehia');
        var st_uni = document.getElementById('st_uni');
        var updateTime = document.getElementById('updateTime');

        const { time } = obj
        const { station } = obj;

        if (station == 6) {
            st_maehia.innerHTML = `
                <div class="stat-title">Good</div>
                <div class="stat-value">${obj.aod.toFixed(0)}</div>
                <div class="stat-desc">ST: มหาวิทยาลัยเชียงใหม่ (แม่เหียะ)</div>
                `

        } else if (station == 106) {
            st_rmutl.innerHTML = `
                <div class="stat-title">Good</div>
                <div class="stat-value">${obj.aod.toFixed(0)}</div>
                <div class="stat-desc">ST: มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา </div>
                `;
            updateTime.innerHTML = `<h1> Updates: ${time}</h1>`;

        } else if (station == 2004) {
            st_engi.innerHTML = `
                <div class="stat-title">Good</div>
                <div class="stat-value">${obj.aod.toFixed(0)}</div>
                <div class="stat-desc">ST: มหาวิทยาลัยเชียงใหม่ (คณะวิศวกรรมศาสตร์)</div>
                `

        } else if (station == 4439) {
            st_uni.innerHTML = `
                <div class="stat-title">Good</div>
                <div class="stat-value">${obj.aod.toFixed(0)}</div>
                <div class="stat-desc">ST: สํานักบริการวิชาการ มหาวิทยาลัยเชียงใหม่ </div>
                `
        }
    });

}


const displayCard = (data) => {

    date = data[0].date
    time = data[0].time
    aod = data[0].aod
    image_name = data[0].image_name
    image_url = `https://www-old.cmuccdc.org/uploads/cam/${image_name}`

    var card = document.getElementById('info-card');
    var card_content = document.getElementById('card-content');

    card_content.innerHTML = `
                    <img src="${image_url}" alt="${image_name}" class="card-image"/>
                    <div class="card-text">
                        <div class="card-text-header">
                            <h2> <b> มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา </b> </h2>
                        </div>

                        <div class="card-text-desc">
                            <p> <b>วันที่:</b> ${date} <b>เวลา:</b> ${time}</p>
                            <p> <b>ค่าฝุ่นละอองลอย:</b> ${aod.toFixed(0)}</p>
                        </div>
                    </div>
                `;
    card.classList.remove('hidden');
    document.body.classList.add('blur-background');
}























// const filter = (dataAPI) => {
//     console.log('const filter = (dataAPI)');

//     let dataObject = [];

//     for (let i = 0; i < dataAPI.length; i++) {
//         let aod = parseFloat(dataAPI[i]["aod"]).toFixed(3);
//         let date = filter_date(dataAPI[i]["date"]);
//         let time = dataAPI[i]["time"].slice(0, 5);
//         let image_name = dataAPI[i]["image_name"];
//         let image_url = `https://www-old.cmuccdc.org/uploads/cam/${image_name}`;

//         let Object = {
//             aod: aod,
//             date: date,
//             time: time,
//             image_name: image_name,
//             image_url: image_url
//         };

//         dataObject.push(Object);

//     }
//     return lastupdate(dataObject);

// }


// const filter_date = (dataAPI) => {
//     console.log('const filter_date = (dataAPI)');

//     let dateObj = new Date(dataAPI);
//     dateObj.setHours(dateObj.getHours() + 7);
//     let day = dateObj.getUTCDate();
//     let month = dateObj.getUTCMonth() + 1;
//     let year = dateObj.getUTCFullYear() + 543;
//     let formattedDate = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}/${year}`;

//     return formattedDate
// }



// const lastupdate = (dataObject) => {

//     console.log(dataObject);


//     for (let i = 0; i < dataAPI.length; i++) {


//     }














// }







